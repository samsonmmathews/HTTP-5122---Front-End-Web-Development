﻿//#### LAB 4 - FUNCTIONS ####
//PART 3:  WALKING THE DOG 


//################## CREATE YOUR checkTemp FUNCTION
//This function will...
//It expects to receive...
//It will return...



//################## LOGIC THAT OUTPUTS MESSAGES BASED ON FUNCTION RESULTS
