//LAB 10 - 2 INVENTORY PAGE








	//ADD MOUSEOVER/MOUSEOUT FUNCTIONS FOR <tr>







	//ADD CLICK EVENT TO <tr>
