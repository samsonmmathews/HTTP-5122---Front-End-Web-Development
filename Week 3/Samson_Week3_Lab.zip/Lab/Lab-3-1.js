//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
var fruits = ["apple", "banana", "grapes", "orange", "pear"];

//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
alert(fruits[0]);